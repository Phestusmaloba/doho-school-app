ST. THOMAS DOHO SCHOOL MANAGEMENT SYSTEM — ANDROID PROJECT

This Android Studio project wraps the supplied school management HTML app in an Android WebView and uses the uploaded DOHO crest as the app icon and in-app logo.

BUILD THE APK
1. Install Android Studio (current stable) on a computer.
2. Open this folder (DohoSchoolApp) in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will create the APK under app/build/outputs/apk/debug/app-debug.apk.
6. Copy that APK to the Android phone and install it. For distribution, create a signed release APK using Build > Generate Signed Bundle / APK.

IMPORTANT DATA / SECURITY NOTES
- This wrapper keeps the original app's browser localStorage-based data model. Data stays on that device/app installation; it does not automatically sync between staff phones or create cloud backups.
- The supplied HTML contains demo login credentials in client-side code. These are not secure production authentication. Do not enter real learner personal data until server-side authentication, authorization, secure database storage, backups, and privacy controls are implemented.
- This project is a buildable Android Studio source project, not a precompiled APK. APK compilation requires Android Studio/Android SDK and Gradle, which are not installed in this environment.
